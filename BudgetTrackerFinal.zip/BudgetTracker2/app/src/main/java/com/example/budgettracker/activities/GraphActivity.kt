package com.example.budgettracker.activities

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.budgettracker.DatabaseHelper
import com.example.budgettracker.R
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.utils.ColorTemplate

class GraphActivity : AppCompatActivity() {

    private lateinit var pieChart: PieChart
    private lateinit var lineChart: LineChart
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_graph)

        pieChart = findViewById(R.id.pieChart)
        lineChart = findViewById(R.id.lineChart)
        databaseHelper = DatabaseHelper(this)

        loadChartData()
        drawSpendingLineChart()
    }

    private fun loadChartData() {
        val startDate = "2025-06-01"
        val endDate = "2025-06-25"
        val spendingData = databaseHelper.getSpendingPerCategory(startDate, endDate)

        val entries = ArrayList<PieEntry>()
        for ((category, amount) in spendingData) {
            entries.add(PieEntry(amount, category))
        }

        val dataSet = PieDataSet(entries, "Spending by Category")
        dataSet.setColors(*ColorTemplate.MATERIAL_COLORS)
        val data = PieData(dataSet)

        pieChart.data = data
        pieChart.description.isEnabled = false
        pieChart.animateY(1000)
        pieChart.invalidate() // refresh

        if (entries.isEmpty()) {
            Toast.makeText(this, "No data to show for this date range.", Toast.LENGTH_SHORT).show()
            return
        }

    }



    private fun drawSpendingLineChart() {
        val sharedPreferences = getSharedPreferences("user_session", Context.MODE_PRIVATE)
        val userId = sharedPreferences.getInt("userId", -1) // default -1 if not found
        val spendingData = databaseHelper.getSpendingPerDay(userId,"2025-06-01", "2025-06-23") // Map<String, Float>
        val goal = databaseHelper.getUserGoal(userId = 1) // Get min/max from DB

        val spendingEntries = ArrayList<Entry>()
        val minGoalEntries = ArrayList<Entry>()
        val maxGoalEntries = ArrayList<Entry>()

        var index = 0f
        for ((date, amount) in spendingData) {
            spendingEntries.add(Entry(index, amount))
            minGoalEntries.add(Entry(index, goal.min))
            maxGoalEntries.add(Entry(index, goal.max))
            index++
        }

        val spendingSet = LineDataSet(spendingEntries, "Actual Spending").apply {
            color = resources.getColor(R.color.teal_700)
            lineWidth = 2f
            setCircleColor(color)
        }

        val minSet = LineDataSet(minGoalEntries, "Min Goal").apply {
            color = resources.getColor(R.color.red)
            lineWidth = 1.5f
            enableDashedLine(10f, 5f, 0f)
        }

        val maxSet = LineDataSet(maxGoalEntries, "Max Goal").apply {
            color = resources.getColor(R.color.green)
            lineWidth = 1.5f
            enableDashedLine(10f, 5f, 0f)
        }

        lineChart.data = LineData(spendingSet, minSet, maxSet)
        lineChart.description.text = "Spending vs Goals"
        lineChart.animateY(1000)
        lineChart.invalidate()
    }
}
