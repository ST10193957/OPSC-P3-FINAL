package com.example.budgettracker.activities

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.content.Context
import androidx.fragment.app.Fragment
import com.example.budgettracker.DatabaseHelper
import com.example.budgettracker.R
import com.example.budgettracker.databinding.ActivityHomeBinding
import com.example.budgettracker.fragments.CategoriesFragment
import com.example.budgettracker.fragments.ExpensesFragment
import com.example.budgettracker.fragments.HomeFragment
import com.example.budgettracker.fragments.IncomesFragment
import com.example.budgettracker.fragments.ProfileFragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet


class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        replaceFragment(HomeFragment())

        // Handle bottom nav item clicks
        binding.bottomNav.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.homeMn -> replaceFragment(HomeFragment())
                R.id.expensesMn -> replaceFragment(ExpensesFragment())
                R.id.budgetsMn -> replaceFragment(IncomesFragment())
                R.id.categoriesMn -> replaceFragment(CategoriesFragment())
                R.id.profileMn -> replaceFragment(ProfileFragment())
                else -> return@setOnItemSelectedListener false
            }
            true
        }

    }
    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

}