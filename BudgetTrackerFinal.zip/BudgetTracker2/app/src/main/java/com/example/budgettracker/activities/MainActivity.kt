package com.example.budgettracker.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.budgettracker.R
import com.example.budgettracker.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.signInRedirectButton.setOnClickListener {
            val intent = Intent(this,UsernameLoginActivity::class.java)
            startActivity(intent)
            finish()
        }
        binding.emailLoginRedirect.setOnClickListener {
            val intent = Intent(this,EmailLoginActivity::class.java)
            startActivity(intent)
            finish()
        }


    }
}