package com.example.budgettracker.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.budgettracker.DatabaseHelper
import com.example.budgettracker.R
import com.example.budgettracker.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    private  lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseHelper = DatabaseHelper(this)

        binding.registerButton.setOnClickListener {
            val username = binding.registerUsernameEt.text.toString().trim()
            val password = binding.registerPassword.text.toString().trim()
            val email = binding.registerEmail.text.toString().trim()

            registerToDatabase(username,password,email)
            val userId = databaseHelper.getUserIdByEmail(email)
            val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
            sharedPreferences.edit().putBoolean("isFirstLogin_$userId", true).apply()
        }
        binding.emailLoginRedirect.setOnClickListener{
            val intent = Intent(this, EmailLoginActivity::class.java)
            startActivity(intent)
            finish()
        }
        binding.usernameLoginRedirect.setOnClickListener{
            val intent = Intent(this, UsernameLoginActivity::class.java)
            startActivity(intent)
            finish()
        }


    }
    private fun registerToDatabase(username: String, password: String, email: String) {
        val insertResult = databaseHelper.insertUser(username, password, email)

        when (insertResult) {
            -2L -> Toast.makeText(this, "Registration Failed: Username already exists!", Toast.LENGTH_SHORT).show()
            -3L -> Toast.makeText(this, "Registration Failed: Email already exists!", Toast.LENGTH_SHORT).show()
            -1L -> Toast.makeText(this, "Registration Failed: Unknown database error.", Toast.LENGTH_SHORT).show()
            else -> {
                Toast.makeText(this, "Registration Successful!!", Toast.LENGTH_SHORT).show()

                // Only now try get the user ID
                val userId = databaseHelper.getUserIdByEmail(email)
                if (userId != null) {
                    val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
                    sharedPreferences.edit().putBoolean("isFirstLogin_$userId", true).apply()
                }

                // Go to login screen
                startActivity(Intent(this, UsernameLoginActivity::class.java))
                finish()
            }
        }
    }


}
