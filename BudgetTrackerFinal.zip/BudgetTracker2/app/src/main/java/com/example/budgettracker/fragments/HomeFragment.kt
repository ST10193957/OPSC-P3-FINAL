package com.example.budgettracker.fragments


import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.budgettracker.DatabaseHelper
import com.example.budgettracker.R
import com.example.budgettracker.activities.GraphActivity
import com.example.budgettracker.databinding.FragmentHomeBinding
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet

class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        databaseHelper = DatabaseHelper(requireContext())

        val sharedPreferences = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE)
        val email = sharedPreferences.getString("email", null)
        val userId = email?.let { databaseHelper.getUserIdByEmail(it) } ?: -1

        if (userId != -1) {
            updateUserUI(userId)
            updateLineChart(userId)
        }

        binding.btnOpenGraph.setOnClickListener {
            startActivity(Intent(requireContext(), GraphActivity::class.java))
        }

        return binding.root
    }

    private fun updateUserUI(userId: Int) {
        val username = databaseHelper.getUsernameById(userId)
        binding.usernameDisplayTv.text = "Hello, $username"

        val income = databaseHelper.getTotalIncomeForUser(userId)
        val expense = databaseHelper.getTotalExpenseForUser(userId)
        val balance = income - expense

        binding.activeBalanceTv.text = "R %.2f".format(balance)
        val colorId = if (balance >= 0) R.color.green else R.color.red
        binding.activeBalanceTv.setTextColor(ContextCompat.getColor(requireContext(), colorId))

        if (databaseHelper.metSpendingGoalThisMonth(userId)) {
            Toast.makeText(requireContext(), "🎉 Great job! You met your spending goal this month!", Toast.LENGTH_LONG).show()
            databaseHelper.awardBadge(userId, "Goal Achiever")
        }
    }

    private fun updateLineChart(userId: Int) {
        val (dates, amounts) = databaseHelper.getSpendingTrend(userId)
        val entries = dates.indices.map { i -> Entry(i.toFloat(), amounts[i]) }

        val dataSet = LineDataSet(entries, "Spending Over Time").apply {
            color = Color.BLUE
            setCircleColor(Color.BLUE)
            valueTextColor = Color.BLACK
            lineWidth = 2f
        }

        binding.lineChart.data = LineData(dataSet)
        binding.lineChart.description.isEnabled = false
        binding.lineChart.invalidate()
    }
}

