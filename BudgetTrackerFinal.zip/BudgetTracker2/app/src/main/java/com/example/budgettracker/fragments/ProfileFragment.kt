package com.example.budgettracker.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.budgettracker.DatabaseHelper
import com.example.budgettracker.R
import com.example.budgettracker.databinding.FragmentProfileBinding


class ProfileFragment : Fragment() {
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        dbHelper = DatabaseHelper(requireContext())
        sharedPreferences = requireContext().getSharedPreferences("user_session", Context.MODE_PRIVATE)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.saveButton.setOnClickListener {
            val minGoal = binding.minGoalEditText.text.toString().toDoubleOrNull()
            val maxGoal = binding.maxGoalEditText.text.toString().toDoubleOrNull()

            if (minGoal == null || maxGoal == null) {
                Toast.makeText(requireContext(), "Please enter valid goals", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val username = sharedPreferences.getString("username", null)
            if (username != null) {
                val userId = dbHelper.getUserId(username)
                if (userId != null) {
                    dbHelper.saveSpendingGoals(userId, minGoal, maxGoal)
                    Toast.makeText(requireContext(), "Goals saved!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "User not found", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "User not logged in", Toast.LENGTH_SHORT).show()
            }
        }
        val sharedPreferences = requireContext().getSharedPreferences("user_session", Context.MODE_PRIVATE)
        val userId = sharedPreferences.getInt("user_id", -1)

        if (userId != -1) {
            val db = DatabaseHelper(requireContext())
            val badges = db.getUserBadges(userId)
            val badgesContainer = view.findViewById<LinearLayout>(R.id.badgesContainer)

            for (badge in badges) {
                val textView = TextView(requireContext()).apply {
                    text = "🏅 $badge"
                    textSize = 16f
                    setPadding(8, 8, 8, 8)
                }
                badgesContainer.addView(textView)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}