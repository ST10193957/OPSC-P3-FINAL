package com.example.budgettracker

data class CategoryItem(
    val categoryName : String,
    val categoryType : Boolean,
    val totalSpent : Int
)
