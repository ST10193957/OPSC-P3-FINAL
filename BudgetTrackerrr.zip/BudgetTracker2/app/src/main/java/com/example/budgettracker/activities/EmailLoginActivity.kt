package com.example.budgettracker.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.budgettracker.DatabaseHelper
import com.example.budgettracker.R
import com.example.budgettracker.databinding.ActivityEmailLoginBinding

class EmailLoginActivity : AppCompatActivity() {

    private  lateinit var binding: ActivityEmailLoginBinding

    private  lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmailLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseHelper = DatabaseHelper(this)

        binding.emailLoginButton.setOnClickListener {
            val email = binding.loginEmail.text.toString().trim()
            val password = binding.emailLoginPassword.text.toString().trim()

            loginToDatabase(email,password)

        }
        binding.registerRedirectText.setOnClickListener{
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
    private fun loginToDatabase(email: String, password: String) {
        if (databaseHelper.readUserByEmail(email, password)) {
            val userId = databaseHelper.getUserIdByEmail(email)
            if (userId != null) {
                val sharedPreferences = getSharedPreferences("user_session", Context.MODE_PRIVATE)
                val isFirstLoginKey = "isFirstLogin_$userId"
                val isFirstLogin = sharedPreferences.getBoolean(isFirstLoginKey, true)

                sharedPreferences.edit {
                    putString("email", email)
                }
                databaseHelper.checkAndAwardBadges(userId)

                val intent = if (isFirstLogin) {
                    // Mark first login done
                    sharedPreferences.edit().putBoolean(isFirstLoginKey, false).apply()
                    Intent(this, CreateCategoriesActivity::class.java)
                } else {
                    Intent(this, HomeActivity::class.java)
                }

                Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Login error: user not found!", Toast.LENGTH_SHORT).show()
            }
        } else if (databaseHelper.checkUserExists(email)) {
            Toast.makeText(this, "Incorrect password!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "User does not exist!", Toast.LENGTH_SHORT).show()
        }
    }
}