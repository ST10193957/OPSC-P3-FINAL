package com.example.budgettracker.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.budgettracker.DatabaseHelper
import com.example.budgettracker.R
import com.example.budgettracker.databinding.ActivityEmailLoginBinding
import com.example.budgettracker.databinding.ActivityUsernameLoginBinding

class UsernameLoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUsernameLoginBinding
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUsernameLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseHelper = DatabaseHelper(this)

        // On Login button click
        binding.usernameLoginButton.setOnClickListener {
            val username = binding.loginUsername.text.toString().trim()
            val password = binding.usernameLoginPassword.text.toString().trim()
            loginToDatabase(username, password)
        }

        // On Register redirect text click
        binding.registerRedirectText.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun loginToDatabase(username: String, password: String) {
        // Check if the user exists and the password is correct
        if (databaseHelper.readUserByUsername(username, password)) {
            val userId = databaseHelper.getUserId(username)
            if (userId != null) {
                val categoryCount = databaseHelper.getCategoryCountForUser(userId)

                // Show successful login message
                Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()

                // Save username in shared preferences
                val sharedPreferences = getSharedPreferences("user_session", Context.MODE_PRIVATE)
                sharedPreferences.edit().apply {
                    putString("username", username) // Save username
                    apply() // Apply changes
                }

                val intent = if (categoryCount >= 3) {
                    Intent(this, HomeActivity::class.java)
                } else {
                    Intent(this, CreateCategoriesActivity::class.java)
                }

                // Start the appropriate activity and finish current one
                startActivity(intent)
                finish()

            } else {
                Toast.makeText(this, "Login error: user not found!", Toast.LENGTH_SHORT).show()
            }
        } else if (databaseHelper.checkUserExists(username)) {
            // Incorrect password
            Toast.makeText(this, "Incorrect password!", Toast.LENGTH_SHORT).show()
        } else {
            // User does not exist
            Toast.makeText(this, "User does not exist!", Toast.LENGTH_SHORT).show()
        }
    }
}
